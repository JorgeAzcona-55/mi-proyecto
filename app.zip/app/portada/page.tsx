import PostCard from "../../components/PostCard"

export default function FeedPage() {

  const posts = [
    {
      user: "devMario",
      text: "Nuevo avance de mi juego RPG 🔥"
    },
    {
      user: "pixelStudio",
      text: "Acabamos de añadir multiplayer!"
    },
    {
      user: "gamer123",
      text: "Este juego indie promete mucho 🎮"
    }
  ]

  return (

    <div className="flex flex-col gap-6 w-full max-w-xl">

      {posts.map((post, i) => (
        <PostCard
          key={i}
          user={post.user}
          text={post.text}
        />
      ))}

    </div>

  )
}